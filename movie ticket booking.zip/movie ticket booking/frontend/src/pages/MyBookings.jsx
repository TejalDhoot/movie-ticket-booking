import { useEffect, useState } from "react";
import { API_BASE } from "../config";

const MyBookings = () => {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchBookings = async () => {
      try {
        const token = localStorage.getItem("token");

        const res = await fetch(`${API_BASE}/bookings/my-bookings`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        const data = await res.json();

        if (res.ok) {
          setBookings(data);
        } else {
          alert(data.error || "Failed to fetch bookings");
        }
      } catch (error) {
        console.error(error);
      } finally {
        setLoading(false);
      }
    };

    fetchBookings();
  }, []);

  if (loading) {
    return <h2 style={{ padding: "40px" }}>Loading bookings...</h2>;
  }

  return (
    <div style={{ padding: "40px" }}>
      <h1>My Bookings</h1>

      {bookings.length === 0 ? (
        <p style={{ marginTop: "20px" }}>No bookings found.</p>
      ) : (
        <div style={styles.grid}>
          {bookings.map((booking, index) => (
            <div key={index} style={styles.card}>
              <h3>{booking.movie_title}</h3>
              <p>🎬 Show Time: {new Date(booking.show_time).toLocaleString()}</p>
              <p>💺 Seat: {booking.seat_number}</p>
              <p>💰 Amount: ₹ {booking.total_amount}</p>
              <p>📌 Status: {booking.status}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

const styles = {
  grid: {
    marginTop: "30px",
    display: "grid",
    gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))",
    gap: "20px",
  },
  card: {
    backgroundColor: "#1e1e1e",
    padding: "20px",
    borderRadius: "10px",
  },
};

export default MyBookings;
