import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { API_BASE } from "../config";

const SeatSelection = () => {
  const { showId } = useParams();
  const navigate = useNavigate();

  const [seats, setSeats] = useState([]);
  const [selectedSeatIds, setSelectedSeatIds] = useState([]);
  const [loading, setLoading] = useState(false);

  const seatPrice = 200; // price per seat

  // 🔥 Fetch seats from backend
  useEffect(() => {
    const fetchSeats = async () => {
      try {
        const res = await fetch(`${API_BASE}/seats/${showId}`);
        const data = await res.json();

        if (res.ok) {
          setSeats(data);
        }
      } catch (error) {
        console.error(error);
      }
    };

    fetchSeats();
  }, [showId]);

  const toggleSeat = (seatId) => {
    if (selectedSeatIds.includes(seatId)) {
      setSelectedSeatIds(selectedSeatIds.filter((id) => id !== seatId));
    } else {
      setSelectedSeatIds([...selectedSeatIds, seatId]);
    }
  };

  const handleBooking = async () => {
    try {
      const token = localStorage.getItem("token");

      if (!token) {
        alert("Please login first");
        navigate("/login");
        return;
      }

      if (selectedSeatIds.length === 0) {
        alert("Select at least one seat");
        return;
      }

      setLoading(true);

      // 🔐 STEP 1: Lock seats
      const lockRes = await fetch(`${API_BASE}/seats/lock`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          seatIds: selectedSeatIds,
        }),
      });

      const lockData = await lockRes.json();

      if (!lockRes.ok) {
        alert(lockData.error);
        setLoading(false);
        return;
      }

      // 💰 Calculate total amount
      const totalAmount = selectedSeatIds.length * seatPrice;

      // 🎟 STEP 2: Confirm booking
      const confirmRes = await fetch(`${API_BASE}/bookings/confirm`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          showId: parseInt(showId),
          seatIds: selectedSeatIds,
          totalAmount: totalAmount, // ✅ FIXED HERE
        }),
      });

      const confirmData = await confirmRes.json();

      if (confirmRes.ok) {
        alert("Booking Successful 🎉");
        navigate("/my-bookings");
      } else {
        alert(confirmData.error);
      }

    } catch (error) {
      console.error(error);
      alert("Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ padding: "40px" }}>
      <h1>Select Seats</h1>

      <div style={styles.grid}>
        {seats.map((seat) => {
          const isSelected = selectedSeatIds.includes(seat.id);
          const isBooked = seat.status === "BOOKED";

          return (
            <div
              key={seat.id}
              onClick={() => !isBooked && toggleSeat(seat.id)}
              style={{
                ...styles.seat,
                backgroundColor: isBooked
                  ? "#777"
                  : isSelected
                  ? "#e50914"
                  : "#444",
                cursor: isBooked ? "not-allowed" : "pointer",
              }}
            >
              {seat.seat_number}
            </div>
          );
        })}
      </div>

      <div style={{ marginTop: "30px" }}>
        <h3>
          Total Amount: ₹ {selectedSeatIds.length * seatPrice}
        </h3>

        {selectedSeatIds.length > 0 && (
          <button
            style={styles.bookBtn}
            onClick={handleBooking}
            disabled={loading}
          >
            {loading ? "Processing..." : "Proceed to Book"}
          </button>
        )}
      </div>
    </div>
  );
};

const styles = {
  grid: {
    display: "grid",
    gridTemplateColumns: "repeat(8, 50px)",
    gap: "10px",
    marginTop: "30px",
  },
  seat: {
    height: "50px",
    width: "50px",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    borderRadius: "6px",
    color: "#fff",
    fontSize: "12px",
  },
  bookBtn: {
    marginTop: "20px",
    padding: "10px 20px",
    backgroundColor: "#e50914",
    color: "#fff",
    border: "none",
    borderRadius: "6px",
    cursor: "pointer",
  },
};

export default SeatSelection;
