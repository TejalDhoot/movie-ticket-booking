import { useState } from "react";
import MovieCard from "../components/MovieCard";

const allMovies = [
  {
    id: 1,
    title: "Interstellar",
    language: "English",
    genre: "Sci-Fi",
    location: "Mumbai",
    rating: "9.0",
    poster:
      "https://image.tmdb.org/t/p/w500/nCbkOyOMTEwlEV0LtCOvCnwEONA.jpg",
  },
  {
    id: 2,
    title: "Inception",
    language: "English",
    genre: "Action",
    location: "Pune",
    rating: "8.8",
    poster:
      "https://image.tmdb.org/t/p/w500/qmDpIHrmpJINaRKAfWQfftjCdyi.jpg",
  },
  {
    id: 3,
    title: "Avengers",
    language: "Hindi",
    genre: "Action",
    location: "Mumbai",
    rating: "8.5",
    poster:
      "https://image.tmdb.org/t/p/w500/RYMX2wcKCBAr24UyPD7xwmjaTn.jpg",
  },
  {
    id: 4,
    title: "Joker",
    language: "English",
    genre: "Drama",
    location: "Delhi",
    rating: "8.4",
    poster:
      "https://image.tmdb.org/t/p/w500/udDclJoHjfjb8Ekgsd4FDteOkCU.jpg",
  },
  {
    id: 5,
    title: "Tenet",
    language: "English",
    genre: "Sci-Fi",
    location: "Bangalore",
    rating: "7.9",
    poster:
      "https://image.tmdb.org/t/p/w500/k68nPLbIST6NP96JmTxmZijEvCA.jpg",
  },
  {
    id: 6,
    title: "KGF",
    language: "Hindi",
    genre: "Action",
    location: "Mumbai",
    rating: "8.2",
    poster:
      "https://image.tmdb.org/t/p/w500/5bFK5d3mVTAvBCXi5NPWH0tYjKl.jpg",
  },
];

const Home = ({ location }) => {
  const [selectedLanguage, setSelectedLanguage] = useState(null);
  const [selectedGenre, setSelectedGenre] = useState(null);

  const filteredMovies = allMovies.filter((movie) => {
    const locationMatch = movie.location === location;
    const languageMatch = selectedLanguage
      ? movie.language === selectedLanguage
      : true;
    const genreMatch = selectedGenre
      ? movie.genre === selectedGenre
      : true;

    return locationMatch && languageMatch && genreMatch;
  });

  return (
    <div style={styles.wrapper}>
      <div style={styles.sidebar}>
        <h3>Filters</h3>

        <div>
          <h4>Language</h4>
          <button onClick={() => setSelectedLanguage("Hindi")} style={styles.filterBtn}>Hindi</button>
          <button onClick={() => setSelectedLanguage("English")} style={styles.filterBtn}>English</button>
          <button onClick={() => setSelectedLanguage(null)} style={styles.clearBtn}>Clear</button>
        </div>

        <div style={{ marginTop: "20px" }}>
          <h4>Genre</h4>
          <button onClick={() => setSelectedGenre("Action")} style={styles.filterBtn}>Action</button>
          <button onClick={() => setSelectedGenre("Drama")} style={styles.filterBtn}>Drama</button>
          <button onClick={() => setSelectedGenre("Sci-Fi")} style={styles.filterBtn}>Sci-Fi</button>
          <button onClick={() => setSelectedGenre(null)} style={styles.clearBtn}>Clear</button>
        </div>
      </div>

      <div style={styles.content}>
        <h1>Movies In {location}</h1>

        {filteredMovies.length === 0 ? (
          <p>No movies available in this location.</p>
        ) : (
          <div style={styles.grid}>
            {filteredMovies.map((movie) => (
              <MovieCard key={movie.id} movie={movie} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

const styles = {
  wrapper: { display: "flex", padding: "30px" },
  sidebar: {
    width: "250px",
    backgroundColor: "#1e1e1e",
    padding: "20px",
    borderRadius: "10px",
    marginRight: "30px",
  },
  filterBtn: {
    display: "block",
    marginBottom: "10px",
    padding: "6px 10px",
    backgroundColor: "#333",
    color: "#fff",
    border: "none",
    borderRadius: "5px",
    cursor: "pointer",
  },
  clearBtn: {
    padding: "5px",
    backgroundColor: "#555",
    color: "#fff",
    border: "none",
    borderRadius: "5px",
    cursor: "pointer",
  },
  content: { flex: 1 },
  grid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))",
    gap: "20px",
    marginTop: "20px",
  },
};

export default Home;
