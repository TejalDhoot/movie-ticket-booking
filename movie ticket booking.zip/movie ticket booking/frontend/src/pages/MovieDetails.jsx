import { useParams, useNavigate } from "react-router-dom";

const movieData = {
  1: {
    title: "Interstellar",
    rating: "9.0",
    language: "English",
    genre: "Sci-Fi",
    description:
      "A team of explorers travel through a wormhole in space in an attempt to ensure humanity's survival.",
    banner:
      "https://image.tmdb.org/t/p/original/rAiYTfKGqDCRIIqo664sY9XZIvQ.jpg",
    shows: ["10:00 AM", "1:30 PM", "6:00 PM", "9:30 PM"],
  },
  2: {
    title: "Inception",
    rating: "8.8",
    language: "English",
    genre: "Action",
    description:
      "A skilled thief is given a chance at redemption if he can successfully perform inception.",
    banner:
      "https://image.tmdb.org/t/p/original/s3TBrRGB1iav7gFOCNx3H31MoES.jpg",
    shows: ["11:00 AM", "3:00 PM", "7:00 PM"],
  },
  3: {
    title: "Avengers",
    rating: "8.5",
    language: "Hindi",
    genre: "Action",
    description:
      "Earth's mightiest heroes must come together to stop a global threat.",
    banner:
      "https://image.tmdb.org/t/p/original/7RyHsO4yDXtBv1zUU3mTpHeQ0d5.jpg",
    shows: ["9:30 AM", "2:00 PM", "8:00 PM"],
  },
  4: {
    title: "Joker",
    rating: "8.4",
    language: "English",
    genre: "Drama",
    description:
      "A mentally troubled comedian embarks on a downward spiral of social revolution.",
    banner:
      "https://image.tmdb.org/t/p/original/n6bUvigpRFqSwmPp1m2YADdbRBc.jpg",
    shows: ["12:00 PM", "5:00 PM", "10:00 PM"],
  },
  5: {
    title: "Tenet",
    rating: "7.9",
    language: "English",
    genre: "Sci-Fi",
    description:
      "A secret agent is given a single word as his weapon to prevent World War III.",
    banner:
      "https://image.tmdb.org/t/p/original/k68nPLbIST6NP96JmTxmZijEvCA.jpg",
    shows: ["10:30 AM", "4:30 PM", "9:00 PM"],
  },
  6: {
    title: "KGF",
    rating: "8.2",
    language: "Hindi",
    genre: "Action",
    description:
      "A young man's rise from poverty to power in the gold mafia world.",
    banner:
      "https://image.tmdb.org/t/p/original/vEKs1d4z9ARJzxGPS2aI5pK38wV.jpg",
    shows: ["11:15 AM", "3:45 PM", "7:45 PM"],
  },
};

const MovieDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const movie = movieData[id];

  if (!movie) {
    return <h1 style={{ padding: "40px" }}>Movie not found</h1>;
  }

  return (
    <div>
      {/* Banner */}
      <div
        style={{
          backgroundImage: `url(${movie.banner})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          height: "350px",
          position: "relative",
        }}
      >
        <div
          style={{
            backgroundColor: "rgba(0,0,0,0.75)",
            height: "100%",
            display: "flex",
            alignItems: "center",
            paddingLeft: "60px",
          }}
        >
          <div>
            <h1 style={{ fontSize: "40px" }}>{movie.title}</h1>
            <p>⭐ {movie.rating}</p>
            <p>{movie.language} • {movie.genre}</p>
          </div>
        </div>
      </div>

      {/* Description & Shows */}
      <div style={{ padding: "40px" }}>
        <h2>About the Movie</h2>
        <p style={{ maxWidth: "700px", marginTop: "10px" }}>
          {movie.description}
        </p>

        <h2 style={{ marginTop: "40px" }}>Select Show Time</h2>

        <div style={{ display: "flex", gap: "15px", marginTop: "20px" }}>
          {movie.shows.map((time, index) => (
            <button
              key={index}
              style={{
                padding: "10px 20px",
                backgroundColor: "#e50914",
                border: "none",
                borderRadius: "6px",
                color: "#fff",
                cursor: "pointer",
              }}
              onClick={() => navigate(`/seats/${id}`)}
            >
              {time}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default MovieDetails;
