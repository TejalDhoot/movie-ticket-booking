import { useNavigate } from "react-router-dom";

const MovieCard = ({ movie }) => {
  const navigate = useNavigate();

  return (
    <div
      style={styles.card}
      onClick={() => navigate(`/movie/${movie.id}`)}
    >
      <div style={styles.imageWrapper}>
        <img src={movie.poster} alt={movie.title} style={styles.image} />
        <div style={styles.rating}>⭐ {movie.rating || "8.5"}</div>
      </div>

      <h3 style={styles.title}>{movie.title}</h3>

      <div style={styles.tags}>
        <span style={styles.tag}>{movie.language}</span>
        <span style={styles.tag}>{movie.genre}</span>
      </div>

      <button
        style={styles.button}
        onClick={(e) => {
          e.stopPropagation();
          navigate(`/movie/${movie.id}`);
        }}
      >
        Book Tickets
      </button>
    </div>
  );
};

const styles = {
  card: {
    backgroundColor: "#1e1e1e",
    borderRadius: "12px",
    padding: "12px",
    cursor: "pointer",
    transition: "transform 0.2s ease",
  },
  imageWrapper: {
    position: "relative",
  },
  image: {
    width: "100%",
    height: "280px",
    objectFit: "cover",
    borderRadius: "10px",
  },
  rating: {
    position: "absolute",
    bottom: "10px",
    left: "10px",
    backgroundColor: "#000",
    padding: "5px 8px",
    borderRadius: "6px",
    fontSize: "14px",
  },
  title: {
    marginTop: "10px",
  },
  tags: {
    display: "flex",
    gap: "8px",
    marginTop: "5px",
  },
  tag: {
    backgroundColor: "#333",
    padding: "4px 8px",
    borderRadius: "5px",
    fontSize: "12px",
  },
  button: {
    marginTop: "10px",
    width: "100%",
    padding: "8px",
    backgroundColor: "#e50914",
    color: "#fff",
    border: "none",
    borderRadius: "6px",
    cursor: "pointer",
  },
};

export default MovieCard;
