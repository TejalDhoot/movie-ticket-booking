import { Link, useNavigate } from "react-router-dom";

const Navbar = ({ location, setLocation }) => {
  const navigate = useNavigate();

  const token = localStorage.getItem("token");
  const isLoggedIn = !!token;

  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/login");
    window.location.reload();
  };

  return (
    <nav style={styles.nav}>
      <div style={styles.left}>
        <Link to="/" style={styles.logo}>
          CineBook
        </Link>

        <select
          value={location}
          onChange={(e) => setLocation(e.target.value)}
          style={styles.location}
        >
          <option>Mumbai</option>
          <option>Pune</option>
          <option>Delhi</option>
          <option>Bangalore</option>
        </select>
      </div>

      <div style={styles.menu}>
        <Link to="/" style={styles.link}>Home</Link>

        {/* 🔐 Show only if logged in */}
        {isLoggedIn && (
          <Link to="/my-bookings" style={styles.link}>
            My Bookings
          </Link>
        )}

        {!isLoggedIn ? (
          <>
            <Link to="/login" style={styles.link}>Login</Link>
            <Link to="/register" style={styles.link}>Register</Link>
          </>
        ) : (
          <>
            <div style={styles.profileIcon}>👤</div>
            <button onClick={handleLogout} style={styles.logoutBtn}>
              Logout
            </button>
          </>
        )}
      </div>
    </nav>
  );
};

const styles = {
  nav: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "15px 40px",
    backgroundColor: "#111",
    color: "#fff",
  },
  left: {
    display: "flex",
    alignItems: "center",
    gap: "20px",
  },
  logo: {
    fontSize: "22px",
    fontWeight: "bold",
    textDecoration: "none",
    color: "#fff",
  },
  location: {
    padding: "6px 10px",
    backgroundColor: "#222",
    color: "#fff",
    border: "1px solid #444",
    borderRadius: "6px",
  },
  menu: {
    display: "flex",
    alignItems: "center",
    gap: "20px",
  },
  link: {
    color: "#fff",
    textDecoration: "none",
  },
  profileIcon: {
    fontSize: "20px",
  },
  logoutBtn: {
    backgroundColor: "#e50914",
    border: "none",
    color: "#fff",
    padding: "6px 12px",
    borderRadius: "6px",
    cursor: "pointer",
  },
};

export default Navbar;
