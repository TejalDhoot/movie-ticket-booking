import { BrowserRouter, Routes, Route } from "react-router-dom";
import { useState } from "react";

import Navbar from "./components/Navbar";
import Home from "./pages/Home";
import Login from "./pages/Login";
import Register from "./pages/Register";
import MyBookings from "./pages/MyBookings";
import MovieDetails from "./pages/MovieDetails";
import SeatSelection from "./pages/SeatSelection";

function App() {
  const [location, setLocation] = useState("Mumbai");

  return (
    <BrowserRouter>
      <Navbar location={location} setLocation={setLocation} />

      <Routes>
        <Route path="/" element={<Home location={location} />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/my-bookings" element={<MyBookings />} />
        <Route path="/movie/:id" element={<MovieDetails />} />
        <Route path="/seats/:showId" element={<SeatSelection />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
