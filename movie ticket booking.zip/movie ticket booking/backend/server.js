require('dotenv').config();

const app = require('./src/app');
const { startSeatUnlockScheduler } = require('./src/scheduler/seatUnlockScheduler');

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);

  // Start auto unlock scheduler
  startSeatUnlockScheduler();

  console.log("⏳ Seat unlock scheduler started (runs every 1 minute)");
});
