const express = require("express");
const router = express.Router();
const bookingController = require("../controllers/bookingController.js");
const { authenticate } = require("../middleware/authMiddleware");

// Confirm booking
router.post("/confirm", authenticate, bookingController.confirmBooking);

// My bookings
router.get("/my-bookings", authenticate, bookingController.getMyBookings);

module.exports = router;
