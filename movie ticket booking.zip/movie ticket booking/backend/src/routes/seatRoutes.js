const express = require('express');
const router = express.Router();
const seatController = require('../controllers/seatController');
const { authenticate } = require('../middleware/authMiddleware');

// Public
router.get('/:showId', seatController.getSeatsByShow);

// Protected
router.post('/lock', authenticate, seatController.lockSeat);
router.post('/release-expired', authenticate, seatController.releaseExpired);

module.exports = router;
