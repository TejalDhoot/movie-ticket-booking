const seatService = require('../services/seatService');

// Debug (temporary)
console.log("Loaded seatService:", seatService);
console.log("Functions:", Object.keys(seatService));

// Get seats
const getSeatsByShow = async (req, res) => {
  try {
    const seats = await seatService.getSeatsByShow(req.params.showId);
    res.json(seats);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};


// 🔒 Lock seats (JWT protected)
const lockSeat = async (req, res) => {
  try {

    const userId = req.user.id;
    const { seatIds } = req.body;

    if (!seatIds || seatIds.length === 0) {
      return res.status(400).json({ error: "Seat IDs required" });
    }

    const result = await seatService.lockMultipleSeats(seatIds, userId);

    res.json(result);

  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};


const releaseExpired = async (req, res) => {
  try {
    await seatService.releaseExpired();
    res.json({ message: "Expired locks released" });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};


module.exports = {
  getSeatsByShow,
  lockSeat,
  releaseExpired
};
