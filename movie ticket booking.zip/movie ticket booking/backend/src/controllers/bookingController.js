const pool = require("../config/db");

/* ===============================
   CONFIRM BOOKING
================================ */
const confirmBooking = async (req, res) => {
  const client = await pool.connect();

  try {
    const userId = req.user.id;
    const { showId, seatIds, totalAmount } = req.body;

    if (!seatIds || seatIds.length === 0) {
      return res.status(400).json({ error: "Seat IDs required" });
    }

    if (!totalAmount) {
      return res.status(400).json({ error: "Total amount required" });
    }

    await client.query("BEGIN");

    const seatCheck = await client.query(
      `SELECT id, status
       FROM seats
       WHERE id = ANY($1)
       FOR UPDATE`,
      [seatIds]
    );

    if (seatCheck.rows.length !== seatIds.length) {
      throw new Error("Some seats not found");
    }

    for (let seat of seatCheck.rows) {
      if (seat.status !== "LOCKED") {
        throw new Error("No valid locked seats found");
      }
    }

    const bookingResult = await client.query(
      `INSERT INTO bookings (user_id, show_id, total_amount, status)
       VALUES ($1, $2, $3, 'CONFIRMED')
       RETURNING id`,
      [userId, showId, totalAmount]
    );

    const bookingId = bookingResult.rows[0].id;

    await client.query(
      `UPDATE seats
       SET status = 'BOOKED',
           booking_id = $1
       WHERE id = ANY($2)`,
      [bookingId, seatIds]
    );

    await client.query("COMMIT");

    res.json({
      message: "Booking confirmed",
      bookingId,
      totalAmount
    });

  } catch (error) {
    await client.query("ROLLBACK");
    res.status(400).json({ error: error.message });
  } finally {
    client.release();
  }
};


/* ===============================
   GET MY BOOKINGS
================================ */
const getMyBookings = async (req, res) => {
  try {
    const userId = req.user.id;

    const result = await pool.query(
      `SELECT 
          b.id AS booking_id,
          b.total_amount,
          b.status,
          b.created_at,
          m.title AS movie_title,
          s.show_time,
          st.seat_number
       FROM bookings b
       JOIN shows s ON b.show_id = s.id
       JOIN movies m ON s.movie_id = m.id
       JOIN seats st ON st.booking_id = b.id
       WHERE b.user_id = $1
       ORDER BY b.created_at DESC`,
      [userId]
    );

    res.json(result.rows);

  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};


module.exports = {
  confirmBooking,
  getMyBookings
};
