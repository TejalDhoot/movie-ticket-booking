const pool = require('../config/db');

// Get seats by show
const getSeatsByShow = async (showId) => {
  const result = await pool.query(
    `SELECT id, seat_number, status 
     FROM seats 
     WHERE show_id = $1
     ORDER BY seat_number`,
    [showId]
  );

  return result.rows;
};


// 🔥 MULTI-SEAT LOCKING (Atomic Transaction)
const lockMultipleSeats = async (seatIds, userId) => {

  const client = await pool.connect();

  try {
    await client.query('BEGIN');

    for (let seatId of seatIds) {

      const seatCheck = await client.query(
        'SELECT status FROM seats WHERE id = $1 FOR UPDATE',
        [seatId]
      );

      if (seatCheck.rows.length === 0) {
        throw new Error(`Seat ${seatId} not found`);
      }

      if (seatCheck.rows[0].status !== 'AVAILABLE') {
        throw new Error(`Seat ${seatId} is not available`);
      }

      await client.query(
        `UPDATE seats
         SET status = 'LOCKED',
             locked_by = $1,
             lock_expiry = NOW() + INTERVAL '5 minutes'
         WHERE id = $2`,
        [userId, seatId]
      );
    }

    await client.query('COMMIT');

    return { message: "Seats locked successfully" };

  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
  }
};


// Release expired locks
const releaseExpired = async () => {
  await pool.query(
    `UPDATE seats
     SET status = 'AVAILABLE',
         locked_by = NULL,
         lock_expiry = NULL
     WHERE status = 'LOCKED'
       AND lock_expiry < NOW()`
  );
};


module.exports = {
  getSeatsByShow,
  lockMultipleSeats,
  releaseExpired
};
