const pool = require('../config/db');


// ✅ Confirm Booking (keep your existing logic)
const confirmBooking = async (userId, showId, totalAmount) => {

  const client = await pool.connect();

  try {
    await client.query('BEGIN');

    const lockedSeats = await client.query(
      `SELECT id FROM seats
       WHERE locked_by = $1
       AND status = 'LOCKED'
       AND lock_expiry > NOW()`,
      [userId]
    );

    if (lockedSeats.rows.length === 0) {
      throw new Error("No valid locked seats found");
    }

    const bookingResult = await client.query(
      `INSERT INTO bookings (user_id, show_id, total_amount, status)
       VALUES ($1, $2, $3, 'CONFIRMED')
       RETURNING id`,
      [userId, showId, totalAmount]
    );

    const bookingId = bookingResult.rows[0].id;

    await client.query(
      `UPDATE seats
       SET status = 'BOOKED',
           booking_id = $1,
           locked_by = NULL,
           lock_expiry = NULL
       WHERE locked_by = $2
       AND status = 'LOCKED'`,
      [bookingId, userId]
    );

    await client.query('COMMIT');

    return { message: "Booking confirmed successfully" };

  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
  }
};


// ✅ NEW: Get My Bookings
const getUserBookings = async (userId) => {

  const result = await pool.query(
    `SELECT 
        b.id AS booking_id,
        b.total_amount,
        b.status,
        b.created_at,
        m.title AS movie_title,
        sh.show_time,
        s.seat_number
     FROM bookings b
     JOIN shows sh ON sh.id = b.show_id
     JOIN movies m ON m.id = sh.movie_id
     JOIN seats s ON s.booking_id = b.id
     WHERE b.user_id = $1
     ORDER BY b.created_at DESC`,
    [userId]
  );

  return result.rows;
};


module.exports = {
  confirmBooking,
  getUserBookings
};
