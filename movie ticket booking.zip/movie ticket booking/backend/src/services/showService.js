const pool = require('../config/db');

exports.getAllShows = async () => {
  const result = await pool.query(`
    SELECT s.id, m.title, t.name AS theatre, s.show_time, s.price
    FROM shows s
    JOIN movies m ON s.movie_id = m.id
    JOIN theatres t ON s.theatre_id = t.id
    ORDER BY s.show_time
  `);

  return result.rows;
};
