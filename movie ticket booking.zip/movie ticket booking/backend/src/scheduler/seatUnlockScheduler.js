const cron = require('node-cron');
const pool = require('../config/db');

const startSeatUnlockScheduler = () => {

  cron.schedule('* * * * *', async () => {
    try {

      await pool.query(
        `UPDATE seats
         SET status = 'AVAILABLE',
             locked_by = NULL,
             lock_expiry = NULL
         WHERE status = 'LOCKED'
           AND lock_expiry < NOW()`
      );

      console.log("Expired seats released");

    } catch (error) {
      console.error("Scheduler error:", error.message);
    }
  });

};

module.exports = { startSeatUnlockScheduler };
