const userService = require('./user.service');

// Register Controller
exports.register = async (req, res) => {
  try {
    const { name, email, password } = req.body;

    const result = await userService.register(name, email, password);

    res.status(201).json(result);

  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};


// Login Controller
exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;

    const result = await userService.login(email, password);

    res.status(200).json(result);

  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};
